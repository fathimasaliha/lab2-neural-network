*# Lab 2: A Neural Network from Scratch*



*Name: Fathimath Saliha*

*Student ID: 70728*



*## 1. Dataset*



*I used the scikit-learn digits dataset to classify handwritten*

*digits from 0 to 9. Each image has 64 input features.*



*I divided pixel values by 16 to scale them to \[0, 1].*

*I converted the labels to one-hot vectors.*



*I used a stratified 70/30 split with random\_state=42:*

*- Training samples: 1257*

*- Testing samples: 540*



*## 2. Network Design*



*The network has two hidden layers:*



*Input (64) → Hidden layer (W) → ReLU →*

*Hidden layer (W) → ReLU → Output (10) → Softmax*



*I tested W = 16 and W = 64.*



*| Parameter | Width 16 | Width 64 |*

*|---|---|---|*

*| W1 | (64, 16) | (64, 64) |*

*| b1 | (16,) | (64,) |*

*| W2 | (16, 16) | (64, 64) |*

*| b2 | (16,) | (64,) |*

*| W3 | (16, 10) | (64, 10) |*

*| b3 | (10,) | (10,) |*



*Weights were sampled from a normal distribution with mean 0*

*and standard deviation 0.01. Biases were initialised to zero.*



*## 3. Forward Propagation and Loss*



*The forward calculations are:*



*Z1 = XW1 + b1*

*A1 = ReLU(Z1)*



*Z2 = A1W2 + b2*

*A2 = ReLU(Z2)*



*Z3 = A2W3 + b3*

*P = softmax(Z3)*



*ReLU(z) = max(0, z).*



*For numerical stability, I subtracted the maximum logit in*

*each row before calculating softmax.*



*For a batch of 32 samples, the output shape was (32, 10).*

*Assertions checked that every row summed to 1 within 1e-6.*



*The cross-entropy loss for a batch of m samples is:*



*L = -(1/m) Σ\_i Σ\_k Y\[i,k] log(P\[i,k])*



*For approximately uniform predictions across 10 classes,*

*the expected loss is ln(10), approximately 2.3026.*



*## 4. Gradient Derivation*



*Let D3 be the derivative of the mean loss with respect to Z3.*



*Combining softmax with cross-entropy gives:*



*D3 = (P - Y) / m*



*Because Z3 = A2W3 + b3, the chain rule gives:*



*dW3 = A2ᵀ D3*

*db3 = sum of D3 over the batch*

*dA2 = D3 W3ᵀ*



*The derivative of ReLU is 1 for positive inputs and 0 for*

*negative inputs. The implementation uses 0 at zero.*



*Therefore:*



*D2 = (D3 W3ᵀ) ⊙ (Z2 > 0)*

*dW2 = A1ᵀ D2*

*db2 = sum of D2 over the batch*



*D1 = (D2 W2ᵀ) ⊙ (Z1 > 0)*

*dW1 = Xᵀ D1*

*db1 = sum of D1 over the batch*



*Here, ᵀ means transpose and ⊙ means element-wise multiplication.*

*Bias gradients are summed over samples because each bias*

*is shared by all samples.*



*## 5. Numerical Gradient Checking*



*I checked 10 randomly selected weights for each width,*

*using a batch of 8 samples and epsilon = 1e-5.*



*The numerical gradient was:*



*g\_numeric = \[L(w + epsilon) - L(w - epsilon)] / (2 × epsilon)*



*I compared it with the analytical gradient using:*



*relative\_error =*

*|g\_numeric - g\_analytic| /*

*max(1e-12, |g\_numeric| + |g\_analytic|)*



*A check passed when relative\_error < 1e-6.*



*| Hidden width | Passed checks | Requirement met |*

*|---|---|---|*

*| 16 | 10/10 | Yes |*

*| 64 | 9/10 | Yes |*



*Both widths met the requirement of at least 9 passing checks.*

*One checked weight at width 64 did not meet the threshold;*

*its cause was not investigated.*



*## 6. Training and Accuracy*



*I trained each configuration for 50 epochs using shuffled*

*mini-batches of size 32 and gradient descent.*



*The update rule was:*



*parameter = parameter - learning\_rate × gradient*



*I tested learning rates 0.001, 0.01, and 0.1.*



*| Hidden width | Learning rate | Test accuracy |*

*|---|---|---|*

*| 16 | 0.001 | 10.19% |*

*| 16 | 0.01 | 10.19% |*

*| 16 | 0.1 | 32.59% |*

*| 64 | 0.001 | 10.19% |*

*| 64 | 0.01 | 10.19% |*

*| 64 | 0.1 | 93.89% |*



*!\[Training loss curves](results/loss\_curves.png)*



*The two smaller learning rates showed little improvement*

*within 50 epochs. Their loss curves stayed near 2.30.*



*With learning rate 0.1, width 16 started improving late,*

*finishing with loss around 1.60.*



*Width 64 with learning rate 0.1 improved earlier and reached*

*a final training loss of about 0.1684. Its loss fluctuated*

*but decreased overall.*



*## 7. Forward and Backward Timing*



*I measured forward and backward passes separately using*

*a batch of 32 samples. After 10 warm-up runs, I recorded*

*the median time from 100 runs.*



*The measured models used learning rate 0.1.*



*| Hidden width | Forward time | Backward time |*

*|---|---|---|*

*| 16 | 0.1029 ms | 0.1168 ms |*

*| 64 | 0.1427 ms | 0.1887 ms |*



*Backward propagation took longer for both widths. It uses*

*matrix multiplications to calculate weight gradients and*

*propagate errors through the hidden layers.*



*Width 64 uses larger matrices, and both passes took longer*

*than at width 16. These timings depend on the computer*

*and can vary between runs.*



*## 8. Conclusion*



*I implemented a two-hidden-layer neural network using NumPy.*

*Both network widths met the numerical gradient-check requirement.*



*The highest observed test accuracy was 93.89%, achieved with*

*width 64 and learning rate 0.1. The experiment showed that*

*learning rate and hidden width affected learning within the*

*fixed limit of 50 epochs.*

