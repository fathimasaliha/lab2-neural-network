import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

# Load handwritten digits
digits = load_digits()

# Scale pixel values from 0–16 to 0–1
X = digits.data / 16.0
y = digits.target

# Convert labels into one-hot vectors
Y = np.eye(10)[y]

# Split: 70% training, 30% testing
X_train, X_test, Y_train, Y_test = train_test_split(
    X,
    Y,
    test_size=0.30,
    random_state=42,
    stratify=y
)

print("Training inputs:", X_train.shape)
print("Testing inputs:", X_test.shape)
print("Training labels:", Y_train.shape)
print("Testing labels:", Y_test.shape)
# Create a network with two hidden layers
def initialise_network(width):
    rng = np.random.default_rng(42)

    return {
        "W1": rng.normal(0, 0.01, (64, width)),
        "b1": np.zeros(width),
        "W2": rng.normal(0, 0.01, (width, width)),
        "b2": np.zeros(width),
        "W3": rng.normal(0, 0.01, (width, 10)),
        "b3": np.zeros(10)
    }


# Check both required network sizes
for width in [16, 64]:
    network = initialise_network(width)

    print(f"\nNetwork width: {width}")
    for name, values in network.items():
        print(name, values.shape)
def forward(X, params):
    z1 = X @ params["W1"] + params["b1"]
    a1 = np.maximum(0, z1)  # ReLU

    z2 = a1 @ params["W2"] + params["b2"]
    a2 = np.maximum(0, z2)  # ReLU

    z3 = a2 @ params["W3"] + params["b3"]

    # Stable softmax
    shifted = z3 - np.max(z3, axis=1, keepdims=True)
    exp_scores = np.exp(shifted)
    probabilities = exp_scores / np.sum(
        exp_scores, axis=1, keepdims=True
    )

    cache = (X, z1, a1, z2, a2, probabilities)
    return probabilities, cache


# Check forward propagation for both widths
for width in [16, 64]:
    params = initialise_network(width)
    probabilities, _ = forward(X_train[:32], params)

    assert probabilities.shape == (32, 10)
    assert np.allclose(
        probabilities.sum(axis=1), 1.0,
        atol=1e-6, rtol=0
    )

    print(f"\nWidth {width}: forward checks passed")
    print("Output shape:", probabilities.shape)
def cross_entropy(probabilities, labels):
    safe_probabilities = np.clip(probabilities, 1e-15, 1.0)
    return -np.mean(
        np.sum(labels * np.log(safe_probabilities), axis=1)
    )


# Check loss before training
for width in [16, 64]:
    params = initialise_network(width)
    probabilities, _ = forward(X_train, params)
    loss = cross_entropy(probabilities, Y_train)

    print(f"\nWidth {width}: initial loss = {loss:.4f}")
def backward(params, cache, labels):
    X, z1, a1, z2, a2, probabilities = cache
    batch_size = X.shape[0]

    # Output layer: softmax with cross-entropy
    dz3 = (probabilities - labels) / batch_size
    dW3 = a2.T @ dz3
    db3 = np.sum(dz3, axis=0)

    # Second hidden layer
    da2 = dz3 @ params["W3"].T
    dz2 = da2 * (z2 > 0)
    dW2 = a1.T @ dz2
    db2 = np.sum(dz2, axis=0)

    # First hidden layer
    da1 = dz2 @ params["W2"].T
    dz1 = da1 * (z1 > 0)
    dW1 = X.T @ dz1
    db1 = np.sum(dz1, axis=0)

    return {
        "W1": dW1, "b1": db1,
        "W2": dW2, "b2": db2,
        "W3": dW3, "b3": db3
    }


# Check gradient shapes for both widths
for width in [16, 64]:
    params = initialise_network(width)
    probabilities, cache = forward(X_train[:32], params)
    gradients = backward(params, cache, Y_train[:32])

    for name in params:
        assert gradients[name].shape == params[name].shape
        assert np.all(np.isfinite(gradients[name]))

    print(f"\nWidth {width}: gradient shapes passed")
def gradient_check(width):
    params = initialise_network(width)
    X_batch = X_train[:8]
    Y_batch = Y_train[:8]

    _, cache = forward(X_batch, params)
    gradients = backward(params, cache, Y_batch)

    rng = np.random.default_rng(123)
    epsilon = 1e-5
    passed = 0

    # Choose 10 distinct random weights across all three layers
    names = ["W1", "W2", "W3"]
    sizes = [params[name].size for name in names]
    boundaries = np.cumsum(sizes)
    choices = rng.choice(sum(sizes), size=10, replace=False)

    print(f"\nGradient check: width {width}")

    for number, choice in enumerate(choices, start=1):
        layer = int(np.searchsorted(boundaries, choice, side="right"))
        name = names[layer]
        offset = int(boundaries[layer - 1]) if layer > 0 else 0
        index = np.unravel_index(int(choice) - offset, params[name].shape)

        original = params[name][index]

        params[name][index] = original + epsilon
        probabilities, _ = forward(X_batch, params)
        loss_plus = cross_entropy(probabilities, Y_batch)

        params[name][index] = original - epsilon
        probabilities, _ = forward(X_batch, params)
        loss_minus = cross_entropy(probabilities, Y_batch)

        params[name][index] = original

        numerical = (loss_plus - loss_minus) / (2 * epsilon)
        analytical = gradients[name][index]

        relative_error = abs(numerical - analytical) / max(
            1e-12, abs(numerical) + abs(analytical)
        )

        success = relative_error < 1e-6
        passed += int(success)

        print(
            f"{number:2d}. {name}{index}: "
            f"error={relative_error:.2e} "
            f"{'PASS' if success else 'FAIL'}"
        )

    print(f"Passed: {passed}/10")
    print("Requirement met:", passed >= 9)


for width in [16, 64]:
    gradient_check(width)
import matplotlib.pyplot as plt
from pathlib import Path

Path("results").mkdir(exist_ok=True)


def train(width, learning_rate):
    params = initialise_network(width)
    rng = np.random.default_rng(42)
    losses = []
    batch_size = 32

    for epoch in range(50):
        indices = rng.permutation(len(X_train))

        for start in range(0, len(indices), batch_size):
            batch = indices[start:start + batch_size]
            X_batch = X_train[batch]
            Y_batch = Y_train[batch]

            _, cache = forward(X_batch, params)
            gradients = backward(params, cache, Y_batch)

            for name in params:
                params[name] -= learning_rate * gradients[name]

        probabilities, _ = forward(X_train, params)
        loss = cross_entropy(probabilities, Y_train)
        losses.append(loss)

        print(
            f"W={width}, LR={learning_rate}, "
            f"Epoch {epoch + 1}/50, Loss={loss:.4f}"
        )

    probabilities, _ = forward(X_test, params)
    predictions = np.argmax(probabilities, axis=1)
    correct_labels = np.argmax(Y_test, axis=1)
    accuracy = np.mean(predictions == correct_labels)

    return params, losses, accuracy


trained_models = {}
summary = []

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

for axis, width in zip(axes, [16, 64]):
    for learning_rate in [0.001, 0.01, 0.1]:
        params, losses, accuracy = train(width, learning_rate)
        trained_models[(width, learning_rate)] = params
        summary.append((width, learning_rate, accuracy))

        axis.plot(
            range(1, 51), losses,
            label=f"LR = {learning_rate}"
        )

    axis.set_title(f"Hidden width = {width}")
    axis.set_xlabel("Epoch")
    axis.set_ylabel("Training loss")
    axis.legend()
    axis.grid(alpha=0.3)

fig.tight_layout()
fig.savefig("results/loss_curves.png", dpi=150)
plt.close(fig)

print("\nFINAL TEST RESULTS")
for width, learning_rate, accuracy in summary:
    print(
        f"Width={width}, LR={learning_rate}: "
        f"Accuracy={accuracy:.2%}"
    )

with open("results/accuracy.csv", "w", encoding="utf-8") as file:
    file.write("width,learning_rate,test_accuracy\n")
    for width, learning_rate, accuracy in summary:
        file.write(f"{width},{learning_rate},{accuracy:.6f}\n")

print("\nSaved loss curves and accuracy results.")
from time import perf_counter


def measure_timing(params):
    X_batch = X_train[:32]
    Y_batch = Y_train[:32]

    # Warm up before measuring
    for _ in range(10):
        _, cache = forward(X_batch, params)
        backward(params, cache, Y_batch)

    forward_times = []
    backward_times = []

    for _ in range(100):
        start = perf_counter()
        _, cache = forward(X_batch, params)
        forward_times.append(perf_counter() - start)

        start = perf_counter()
        backward(params, cache, Y_batch)
        backward_times.append(perf_counter() - start)

    return (
        np.median(forward_times) * 1000,
        np.median(backward_times) * 1000
    )


print("\nTIMING RESULTS — batch size 32")

with open("results/timing.csv", "w", encoding="utf-8") as file:
    file.write("width,learning_rate,forward_ms,backward_ms\n")

    for width in [16, 64]:
        params = trained_models[(width, 0.1)]
        forward_ms, backward_ms = measure_timing(params)

        print(
            f"Width {width}: "
            f"Forward={forward_ms:.4f} ms, "
            f"Backward={backward_ms:.4f} ms"
        )

        file.write(
            f"{width},0.1,{forward_ms:.6f},{backward_ms:.6f}\n"
        )